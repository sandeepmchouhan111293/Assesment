export class State {
  constructor(public id: number, public countryid: int, public name: string) { }
}
